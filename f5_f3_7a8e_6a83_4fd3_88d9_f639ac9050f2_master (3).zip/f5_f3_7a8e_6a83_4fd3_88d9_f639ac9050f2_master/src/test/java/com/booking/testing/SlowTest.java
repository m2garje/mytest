package com.booking.testing;

public @interface SlowTest {
}
